﻿using ElevatorApp.Elevator.ElevatorStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ElevatorApp.Elevator.ElevatorStates.ElevatorState;

namespace ElevatorApp.Elevator
{
    public class Sensor
    {
    }
}
