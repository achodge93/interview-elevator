﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElevatorApp.Elevator
{
    public class ElevatorCommand
    {
        public bool ShouldStop { get; set; }
        public bool IsInElevator { get; set; }
    }
}
